﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerControll : MonoBehaviour
{
    Animator animator;
    Rigidbody rbody;      // 물리 변수    
    public float speed = 3.0f;  // 이동 속도 변수
    float Force = 10.0f;
    float yPos;
    int x = 1;
    void Start()
    {
        rbody = this.GetComponent<Rigidbody>();  // 이동용 물리 설정 요소를 가져온다.
        Vector3 v1 = new Vector3(speed, 0, 0);

        rbody.velocity = new Vector3(speed, 0, 0);

    }

    void FixedUpdate()
    {
        
        switch (x)
        {
            case 0:
                yPos = -4.6f; break;
            case 1:
                yPos = -1.0f; break;
            case 2:
                yPos = 3.5f; break;
        }
        rbody.velocity = new Vector3(speed, 0, 0);
        float xPos = transform.position.x;
        transform.position = new Vector3(xPos, yPos, 0f);

    }


}